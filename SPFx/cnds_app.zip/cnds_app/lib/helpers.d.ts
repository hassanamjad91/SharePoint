import { AxiosError } from 'axios';
import { Log_Type } from './enums';
export declare const Get: (url: string) => import("axios").AxiosPromise<any>;
export declare const Post: (api_url: string, web_url: string, method: string, data?: any, stringify?: boolean) => Promise<import("axios").AxiosResponse<any>>;
export declare const Get_Digest: (web_url: any) => import("axios").AxiosPromise<any>;
export declare const Log: (log: any, log_type: Log_Type, app_title: string, web_url: string) => Promise<import("axios").AxiosResponse<any>>;
export declare const HTTP_Exception: (e: AxiosError<any>) => void;
export declare const Exception: (err: any, app_title: string, web_url: string, callback_func?: Function) => Promise<void>;
export declare const Is_Object_Empty: (obj: any) => boolean;
export declare const SP_List_Item_Type: (name: any) => string;
export declare const Url_Params: (url?: any) => {};
export declare const Key_Value_Pair: (object: object) => object;
export declare const Redirect: (url: string, no_delay?: boolean) => void;
export declare const UUID_v4: () => string;
export declare const CKEditor4_Config: {
    allowedContent: boolean;
    resize_enabled: boolean;
    enterMode: number;
    shiftEnterMode: number;
    plugins: string;
    removeButtons: string;
    toolbar: string[][];
};
//# sourceMappingURL=helpers.d.ts.map