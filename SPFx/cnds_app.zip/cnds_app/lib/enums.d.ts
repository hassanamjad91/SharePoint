export declare const Questionnaire_Statuses: string[];
export declare enum Questionnaire_Status {
    In_Progress = "In Progress",
    Completed = "Completed"
}
export declare enum Notification_Status {
    Draft = "Draft",
    In_Progress = "In Progress",
    Sent = "Sent",
    Canceled = "Canceled"
}
export declare enum Task_Status {
    Not_Started = "Not Started",
    Draft = "Draft",
    Submitted = "Submitted"
}
export declare enum Log_Type {
    Error = "Error",
    Trace = "Trace"
}
export declare enum Question_Type {
    Toggle = "toggle",
    Radio = "radio",
    Dropdown = "dropdown",
    Text = "text",
    Note = "note",
    Static = "static"
}
export declare enum Input_Type {
    Text = "Text",
    Rich_Text = "RichText",
    Note = "Note",
    Number = "Number",
    Radio = "Radio",
    Dropdown = "Dropdown",
    Toggle = "Toggle",
    Checkbox = "Checkbox",
    Person = "Person",
    File = "File"
}
export declare enum Notification_Send_To {
    Entire_Dist_List = "Entire Distribution List",
    Non_Respondents = "Non-Respondents",
    Others = "Others"
}
export declare enum App_State {
    Error = "Error",
    Pre_Rendering = "Pre_Rendering",
    Pre_Render_Complete = "Pre_Render_Complete",
    Not_Found = "Not_Found",
    UnAuthorized = "UnAuthorized"
}
//# sourceMappingURL=enums.d.ts.map