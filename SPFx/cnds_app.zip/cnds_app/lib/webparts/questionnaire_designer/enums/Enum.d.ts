export declare enum LogType {
    Error = "Error",
    Trace = "Trace"
}
export declare enum HTTP_Method {
    CONNECT = "CONNECT",
    DELETE = "DELETE",
    GET = "GET",
    HEAD = "HEAD",
    OPTIONS = "OPTIONS",
    PATCH = "PATCH",
    POST = "POST",
    MERGE = "MERGE",
    PUT = "PUT",
    TRACE = "TRACE"
}
export declare enum Rule {
    Questionnaire_Start = "questionnaire start",
    Questionnaire_Update = "mark questionnaire for updation",
    Question_Add = "add new to the questions list",
    Question_Update = "mark question for updation",
    Question_Delete = "mark question for deletion and then remove it from the form",
    Question_Move = "swap two questions that are siblings",
    Choice_Add = "add new choice option",
    Choice_Delete = "delete choice option",
    Disabled_Field = "disable rules that apply for all/specific field(s)",
    Disabled = "disable rules that apply to all form elements"
}
export declare enum Field_Type {
    Text = 2,
    Note = 3,
    Lookup = 7
}
export declare enum Data_Type {
    Lookup = "Lookup",
    Note = "Note"
}
export declare enum Base_Template {
    Custom_List = 100
}
export declare enum View_Type {
    HTML = "HTML",
    GANTT = "GANTT",
    GRID = "GRID",
    CHART = "CHART",
    CALENDAR = "CALENDAR",
    RECURRENCE = "RECURRENCE"
}
export declare enum Entity_Type {
    List = "SP.List",
    View = "SP.View",
    Field = "SP.Field",
    FieldXml = "SP.XmlSchemaFieldCreationInformation"
}
declare const _default: {};
export default _default;
//# sourceMappingURL=Enum.d.ts.map