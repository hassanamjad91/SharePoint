import "core-js/es6/symbol";
import "core-js/es6/array";
//# sourceMappingURL=polyfills.d.ts.map