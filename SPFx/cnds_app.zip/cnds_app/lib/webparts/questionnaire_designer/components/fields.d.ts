import { Question_Type, Questionnaire_Status } from '../../../enums';
export declare const question: {
    question_id: {
        key: string;
        value: number;
    };
    question_desc: {
        key: string;
        value: string;
    };
    question_heading: {
        key: string;
        value: string;
    };
    question_show_if_parent: {
        key: string;
        value: string;
    };
    question_order_no: {
        key: string;
        value: string;
    };
    question_type: {
        key: string;
        value: Question_Type;
    };
    question_parent_id: {
        key: string;
        value: number;
    };
    answer_column: {
        key: string;
        value: string;
    };
    answer_choices: {
        key: string;
        value: string[];
    };
    answer_required: {
        key: string;
        value: boolean;
    };
    guid: {
        key: string;
        value: string;
    };
};
export declare const questionnaire: {
    questionnaire_id: {
        key: string;
        value: number;
    };
    questionnaire_title: {
        key: string;
        value: string;
    };
    questionnaire_heading: {
        key: string;
        value: string;
    };
    questionnaire_year: {
        key: string;
        value: string;
    };
    questionnaire_answer_list: {
        key: string;
        value: {
            title: string;
            url: string;
        };
    };
    questionnaire_statement: {
        key: string;
        value: string;
    };
    questionnaire_author: {
        key: string;
        value: {
            Id: number;
            Title: string;
        };
    };
    questionnaire_status: {
        key: string;
        value: Questionnaire_Status;
    };
    questionnaire_group: {
        key: string;
        value: number;
    };
    questions: {
        key: string;
        value: any[];
    };
    __updated: {
        key: string;
        value: boolean;
    };
};
//# sourceMappingURL=fields.d.ts.map