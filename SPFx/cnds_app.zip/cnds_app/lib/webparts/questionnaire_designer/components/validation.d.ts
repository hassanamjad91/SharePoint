import * as Yup from 'yup';
declare const validation: Yup.ObjectSchema<object & {
    [x: string]: any;
}>;
export default validation;
//# sourceMappingURL=validation.d.ts.map