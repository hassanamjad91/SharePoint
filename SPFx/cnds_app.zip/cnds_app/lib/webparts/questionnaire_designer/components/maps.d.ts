export declare const question_type: {
    toggle: string;
    radio: string;
    dropdown: string;
    text: string;
    note: string;
    static: string;
};
export declare const questionnaire_status: {
    in_progress: string;
    completed: string;
};
export declare const input_type: {
    toggle: string;
    radio: string;
    dropdown: string;
    text: string;
    note: string;
    static: string;
    number: string;
    rich_text: string;
};
export declare const params: {
    questionnaire_id: string;
    debug: string;
    src: string;
};
export declare const sp_cols: {
    _generic: {
        Id: string;
        Title: string;
        LinkTitle: string;
        Author: string;
        Modified: string;
        Created: string;
        AttachmentFiles: string;
        Name: string;
        Email: string;
        EMail: string;
    };
    questionnaire: {
        Year: string;
        Heading: string;
        Status: string;
        Statement: string;
        Group: string;
        AnswersListTitle: string;
        AnswersListUrl: string;
    };
    questions: {
        Heading: string;
        Question: string;
        OrderNo: string;
        ShowIFParentAnswer: string;
        Questionnaire: string;
        ParentQuestion: string;
        AnswerColumnName: string;
        Required: string;
        QuestionType: string;
        Choices: string;
    };
    log: {
        Log: string;
        UserId: string;
        LogType: string;
    };
};
export declare const sp_lists: {
    questionnaire: {
        id: string;
        uri: string;
        title: string;
    };
    questions: {
        id: string;
        uri: string;
        title: string;
    };
    notification: {
        uri: string;
        title: string;
    };
    groups: {
        id: string;
        uri: string;
        title: string;
    };
    log: {
        id: string;
        uri: string;
        title: string;
    };
};
declare const _default: {};
export default _default;
//# sourceMappingURL=maps.d.ts.map