import { ILookup } from '../interfaces/Interface';
export declare const question_types: string[];
export declare const groups: ILookup[];
declare const _default: {};
export default _default;
//# sourceMappingURL=dropdowns.d.ts.map