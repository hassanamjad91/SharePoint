declare const styles: {
    app: string;
    container: string;
    grid: string;
    row: string;
    column: string;
    'ms-Grid': string;
    col_1: string;
    col_2: string;
    col_3: string;
    col_4: string;
    col_8: string;
    col_10: string;
    col_12: string;
    title: string;
    subTitle: string;
    description: string;
    button: string;
    label: string;
    disabled: string;
    invalid: string;
    error: string;
    warning: string;
    success: string;
};
export default styles;
//# sourceMappingURL=style.module.scss.d.ts.map