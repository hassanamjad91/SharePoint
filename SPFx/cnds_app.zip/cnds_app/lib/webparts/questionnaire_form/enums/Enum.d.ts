export declare enum LogType {
    Error = "Error",
    Trace = "Trace"
}
declare const _default: {};
export default _default;
//# sourceMappingURL=Enum.d.ts.map