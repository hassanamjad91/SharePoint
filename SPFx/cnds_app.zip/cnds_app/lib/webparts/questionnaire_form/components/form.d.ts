import * as React from 'react';
import { App_State } from '../../../enums';
import { IWebpart, IQuestion_Field, IPerson } from '../../../interfaces';
import { Formik, FormikValues } from 'formik';
declare class Main extends React.Component<IWebpart, {}> {
    state: {
        app_state: App_State;
    };
    form: Formik;
    values: FormikValues;
    is_submitting: boolean;
    is_form_invalid: boolean;
    is_disable_form: boolean;
    url_params: {};
    src_url: any;
    check_icon: string;
    user: IPerson;
    web_url: string;
    Question(field: IQuestion_Field): JSX.Element;
    Render_Questions(): JSX.Element;
    Get_Current_User(): Promise<void>;
    Get_Submission_Task(task_id: number): Promise<number>;
    Get_Questionnaire(questionnaire_id: number): Promise<string>;
    Get_Questions(questionnaire_id: number): Promise<void>;
    Get_Answers(list_title: string): Promise<void>;
    On_Change(target: string): void;
    On_Submit(e: FormikValues): void;
    Set_Error_State(err?: any): void;
    Is_Display_Question(questions: any[], field_key?: string): void;
    Is_Disable_Form(): boolean;
    Is_Disable_Field(field_key: string): boolean;
    Is_Display_Field(field_key: string): boolean;
    Question_Has_Child(index: number, questions: any[]): boolean;
    Question_Parent_Index(index: number, questions: any[]): number;
    Init_Values(): {};
    Close_App(no_delay?: boolean): void;
    componentDidMount(): void;
    render(): JSX.Element;
}
export default Main;
//# sourceMappingURL=form.d.ts.map