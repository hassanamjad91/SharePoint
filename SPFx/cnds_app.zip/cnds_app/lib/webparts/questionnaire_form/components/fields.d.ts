import { Task_Status } from '../../../enums';
export declare const question: {
    question_id: {
        key: string;
        value: number;
    };
    question_desc: {
        key: string;
        value: string;
    };
    question_is_active: {
        key: string;
        value: boolean;
    };
    question_show_if_parent: {
        key: string;
        value: boolean;
    };
    question_order_no: {
        key: string;
        value: string;
    };
    question_type: {
        key: string;
        value: string;
    };
    question_heading: {
        key: string;
        value: string;
    };
    answer: {
        key: string;
        value: string;
    };
    answer_column: {
        key: string;
        value: string;
    };
    answer_choices: {
        key: string;
        value: string;
    };
    __required: {
        key: string;
        value: boolean;
    };
    __display: {
        key: string;
        value: boolean;
    };
};
export declare const questionnaire: {
    submission_id: {
        key: string;
        value: number;
    };
    submission_status: {
        key: string;
        value: Task_Status;
        label: string;
    };
    questionnaire_id: {
        key: string;
        value: number;
    };
    questionnaire_heading: {
        key: string;
        value: string;
        label: string;
    };
    questionnaire_status: {
        key: string;
        value: string;
        label: string;
    };
    questionnaire_statement: {
        key: string;
        label: string;
        value: string;
    };
    questionnaire_allow_draft: {
        key: string;
        value: boolean;
    };
    answers_list_title: {
        key: string;
        value: string;
    };
    answers_list_url: {
        key: string;
        value: string;
    };
    answer_id: {
        key: string;
        value: number;
    };
    submitter: {
        key: string;
        value: {
            Id: number;
            Title: string;
        };
        label: string;
    };
    questions: {
        key: string;
        value: any[];
        label: string;
    };
    __submit: {
        key: string;
        value: number;
    };
    __is_submitted: {
        key: string;
        value: boolean;
    };
};
//# sourceMappingURL=fields.d.ts.map