import { EnvironmentType } from "@microsoft/sp-core-library";
declare const config: {
    app: string;
    env: EnvironmentType;
    user: {
        Id: number;
        Name: string;
        Title: string;
    };
    paths: {
        api: string;
        web: string;
        site: string;
        current: string;
    };
};
export default config;
//# sourceMappingURL=config.d.ts.map