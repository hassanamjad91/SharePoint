import * as React from 'react';
import { App_State } from '../../../enums';
import { IWebpart, IField, ILookup, IPerson } from '../../../interfaces';
import { Formik, FormikValues } from 'formik';
declare class Main extends React.Component<IWebpart, {}> {
    state: {
        app_state: App_State;
    };
    form: Formik;
    values: FormikValues;
    is_submitting: boolean;
    is_disable_form: boolean;
    is_form_invalid: boolean;
    poeple_input_ref: React.RefObject<HTMLInputElement>;
    url_params: {};
    user: IPerson;
    questionnaires: ILookup[];
    web_url: any;
    Field(field: IField): JSX.Element;
    Render_Fields(): JSX.Element;
    Render_Command_Bar(): JSX.Element;
    Render_User_Submissions(): JSX.Element;
    Render_Notifications(): JSX.Element;
    Get_Current_User(): Promise<void>;
    Get_Questionnaire(q_id: number): Promise<void>;
    Get_Questionnaire_Notifications(q_id: number): Promise<void>;
    Get_Questionnaire_Submission_Tasks(q_id: number): Promise<void>;
    Get_Questionnaires(): Promise<void>;
    Update_Questionnaire_Status(q_id: number, status: string): void;
    Get_Questionnaire_Detail(q_id: number): void;
    On_Change(target: string): void;
    On_Submit(e: FormikValues): void;
    Set_Error_State(err?: any): void;
    Is_Disable_Form(): boolean;
    Is_Disable_Field(field_key: string): boolean;
    Is_Display_Field(field_key: string): boolean;
    Init_Values(): {};
    componentDidMount(): void;
    render(): JSX.Element;
}
export default Main;
//# sourceMappingURL=form.d.ts.map