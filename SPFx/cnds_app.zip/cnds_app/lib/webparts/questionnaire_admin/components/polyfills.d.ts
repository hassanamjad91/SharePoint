import "core-js/es6/array";
//# sourceMappingURL=polyfills.d.ts.map