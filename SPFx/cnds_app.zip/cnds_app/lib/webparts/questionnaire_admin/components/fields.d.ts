export declare const fields: {
    questionnaire_id: {
        key: string;
        value: number;
        label: string;
    };
    questionnaire_author: {
        key: string;
        value: {
            Id: number;
            Title: string;
        };
        label: string;
    };
    questionnaire_status: {
        key: string;
        value: string;
        label: string;
        options: string[];
    };
    questionnaire_answer_list: {
        key: string;
        value: {
            title: string;
            url: string;
        };
    };
    user_submissions: {
        key: string;
        value: any[];
        label: string;
    };
    notifications: {
        key: string;
        value: any[];
        label: string;
    };
};
//# sourceMappingURL=fields.d.ts.map