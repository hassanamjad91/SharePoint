import * as Yup from 'yup';
declare const validation: Yup.ObjectSchema<object>;
export default validation;
//# sourceMappingURL=validation.d.ts.map