import { Notification_Status } from '../../../enums';
export declare const fields: {
    notification_id: {
        key: string;
        value: number;
    };
    notification_status: {
        key: string;
        value: Notification_Status;
        label: string;
    };
    notification_subject: {
        key: string;
        value: string;
        label: string;
    };
    notification_body: {
        key: string;
        value: string;
        label: string;
    };
    notification_author: {
        key: string;
        value: {
            Id: number;
            Title: string;
        };
        label: string;
    };
    notification_attachments: {
        key: string;
        value: any[];
        label: string;
    };
    notification_others: {
        key: string;
        value: string;
        label: string;
    };
    notification_send_to: {
        key: string;
        value: string;
        label: string;
    };
    notification_template: {
        key: string;
        value: number;
        label: string;
    };
    notification_call_to_action: {
        key: string;
        value: string;
        label: string;
    };
    questionnaire_id: {
        key: string;
        value: number;
    };
    questionnaire_author: {
        key: string;
        value: {
            Id: number;
            Title: string;
        };
        label: string;
    };
    questionnaire_status: {
        key: string;
        value: string;
        label: string;
    };
    questionnaire_year: {
        key: string;
        value: string;
        label: string;
    };
    questionnaire_title: {
        key: string;
        value: string;
        label: string;
    };
    __ckeditor_loaded: {
        key: string;
        value: boolean;
    };
    __submitted: {
        key: string;
        value: boolean;
    };
};
//# sourceMappingURL=fields.d.ts.map