import * as React from 'react';
import { App_State } from '../../../enums';
import { IIconProps } from 'office-ui-fabric-react/lib';
import { IWebpart, IField, IFile, IEmail_Template, IPerson } from '../../../interfaces';
import { Formik, FormikValues } from 'formik';
declare class Main extends React.Component<IWebpart, {}> {
    state: {
        app_state: App_State;
    };
    form: Formik;
    values: FormikValues;
    is_submitting: boolean;
    is_form_invalid: boolean;
    is_submit: boolean;
    is_disable_form: boolean;
    file_input_ref: React.RefObject<HTMLInputElement>;
    poeple_input_ref: React.RefObject<HTMLInputElement>;
    url_params: {};
    user: IPerson;
    email_templates: IEmail_Template[];
    src_url: any;
    send_icon: IIconProps;
    back_icon: IIconProps;
    save_icon: IIconProps;
    web_url: string;
    Field(field: IField): JSX.Element;
    Render_Fields(): JSX.Element;
    Get_Current_User(): Promise<void>;
    Get_Attachments(id: number): Promise<void>;
    Get_Questionnaire(id: number): Promise<any[]>;
    Get_Notification(id: number): Promise<number>;
    Get_Email_Templates(ids: number[]): Promise<void>;
    Update_Notification_Status(id: number, is_submit: boolean): Promise<void>;
    Save_Attachments(id: number, attachments: IFile[]): Promise<void>;
    Create_Notification(id: number, e: FormikValues): Promise<any>;
    On_Change(target: string): void;
    On_Submit(e: FormikValues): void;
    Set_Error_State(err?: any): void;
    Copy_From_Email_Template(): void;
    Is_Disable_Form(): boolean;
    Is_Disable_Field(key: string): boolean;
    Is_Display_Field(key: string): boolean;
    Init_Values(): FormikValues;
    Close_App(no_delay?: boolean): void;
    componentDidMount(): void;
    render(): JSX.Element;
}
export default Main;
//# sourceMappingURL=form.d.ts.map