declare const _default: {};
export default _default;
//# sourceMappingURL=Enum.d.ts.map