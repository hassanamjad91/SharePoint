export declare const SP_Rest_Proxy = "https://localhost:4444";
export declare const App_Title_Questionnaire_Designer = "Questionnaire Designer";
export declare const App_Title_Questionnaire_Notification = "Questionnaire Notification";
export declare const App_Title_Questionnaire_Form = "Questionnaire Form";
export declare const App_Title_CNDS_Dashboard = "Central Administration";
export declare const Path_Current_Folder: string;
export declare const Path_Home: string;
export declare const Path_Questionnaire_App: string;
export declare const Path_Questionnaire_Notification_App: string;
export declare const Path_Questionnaire_Designer_App: string;
export declare const Path_CNDS_Dashboard_App: string;
export declare const Path_Site_Contents_Page = "/_layouts/15/viewlsts.aspx";
export declare const List_Title_Questionnaire = "Questionnaires";
export declare const List_Title_Questions = "Questions";
export declare const List_Title_Send_Notification = "Send Notification";
export declare const List_Title_Email_Templates = "Email Templates";
export declare const List_Title_User_Submission = "User Submission";
export declare const List_Title_Dist_List = "Distribution List";
export declare const List_Title_Logs = "Logs";
export declare const List_URI_Questionnaire = "Questionnaire";
export declare const List_URI_Questions = "Questions";
export declare const List_URI_Send_Notification = "SendNotification";
export declare const List_URI_Email_Templates = "EmailTemplates";
export declare const List_URI_User_Submission = "UserSubmission";
export declare const List_URI_Dist_List = "DistributionList";
export declare const List_URI_Logs = "Logs";
export declare const User_Message_App_Loading = "Loading Application. Please Wait...";
export declare const User_Message_Saving = "Saving changes..";
export declare const User_Message_Saved = "Changes Saved Successfully";
export declare const User_Message_UnAuthorized = "Sorry! You are not allowed to access this resource.";
export declare const User_Message_Not_Found = "Sorry! The resource you are trying to access could not be found.";
export declare const User_Message_Error = "Sorry! something went wrong. We're working on it.";
export declare const User_Message_Invalid_Form = "Please make sure all highlighted fields are filled out.";
export declare const User_Message_Questions_Not_Found = "No questions to display here.";
export declare const Columns_SharePoint: {
    Id: string;
    Title: string;
    Author: string;
    Created: string;
    Modified: string;
    AttachmentFiles: string;
    Name: string;
    Email: string;
    EMail: string;
};
export declare const Columns_Questionnaire_List: {
    Year: string;
    Heading: string;
    Status: string;
    EmailTemplates: string;
    AnswersListTitle: string;
    AnswersListUrl: string;
};
export declare const Columns_Notification_List: {
    NotificationSendTo: string;
    Others: string;
    EmailTemplate: string;
    Questionnaire: string;
    EmailContent: string;
    Body: string;
    Subject: string;
    Status: string;
    SendEmail: string;
    CallToActionText: string;
};
export declare const Columns_Email_Template_List: {
    Subject: string;
    Body: string;
    CallToActionText: string;
};
export declare const Columns_Log_List: {
    Log: string;
    LogType: string;
};
export declare const Columns_User_Submissions_List: {
    Questionnaire: string;
    Submitter: string;
    Status: string;
};
export declare const URL_Parameters: {
    Notification_Id: string;
    Questionnaire_Id: string;
    Task_Id: string;
    Debug: string;
    Source: string;
};
export declare const Black_List_File_Extension: string[];
export declare const Choices_Notification_Send_To: string[];
//# sourceMappingURL=constants.d.ts.map