import { WebPartContext } from '@microsoft/sp-webpart-base';
import { Environment } from '@microsoft/sp-core-library';
import { Question_Type } from './enums';
export interface IWebpart {
    context: WebPartContext;
    env_type: Environment;
}
export interface IList_Attachment {
    ServerRelativeUrl: string;
    FileName: string;
}
export interface IFile {
    native?: File;
    uploaded?: IList_Attachment;
    __deleted: boolean;
}
export interface IPerson {
    Id: number;
    Title?: string;
    Email?: string;
    EMail?: string;
}
export interface ILookup {
    Id: number;
    Title: string;
}
export interface IUrl {
    title: string;
    url: string;
}
export interface INotification {
    Id: number;
    Status: string;
    Author: IPerson;
    NotificationSendTo: string;
    Created: string;
}
export interface IUserSubmission {
    Id: number;
    Status: string;
    Author: IPerson;
    Submitter: IPerson;
    Created: string;
}
export interface IField {
    key: string;
    value: any;
    type?: string;
    label?: string;
    class?: string;
    options?: ILookup[] | any[];
    readonly?: boolean;
}
export interface IQuestion_Field {
    key: string;
    value: any;
    type: Question_Type;
    label?: string;
    class?: string;
    options?: string[];
}
export interface IEmail_Template {
    Id: number;
    Title: string;
    Subject: string;
    Body: string;
    CallToActionText: string;
}
export interface IQuestion {
    Id: number;
    Title: string;
    Question: string;
    Heading: string;
    OrderNo: string;
    ShowIFParentAnswer: boolean;
    AnswerColumnName: string;
    QuestionType: string;
    Required: boolean;
    Choices: string;
    ParentQuestion: ILookup;
}
export interface IQuestionnaire {
    Id: number;
    Title: string;
    Heading: string;
    Status: string;
    Year: string;
    AnswersListTitle: string;
    AnswersListUrl: string;
    Statement: string;
    Author: IPerson;
    Submit: boolean;
}
//# sourceMappingURL=interfaces.d.ts.map