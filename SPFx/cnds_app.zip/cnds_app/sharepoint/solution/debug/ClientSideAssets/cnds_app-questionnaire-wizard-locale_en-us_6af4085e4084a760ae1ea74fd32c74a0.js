define([], function() {
  return {
    "PropertyPaneDescription": "CNDS Questionnaire Creation Webpart",
    "BasicGroupName": "Group: CNDS",
    "DescriptionFieldLabel": "About:",
    "DescriptionFieldValue": "CNDS Questionnaire Creation Form For Admins"
  };
});
