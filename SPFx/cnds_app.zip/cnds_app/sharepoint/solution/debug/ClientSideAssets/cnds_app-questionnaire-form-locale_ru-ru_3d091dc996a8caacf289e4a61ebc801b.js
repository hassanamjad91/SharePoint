define([], function () {
  return {
    "PropertyPaneDescription": "CNDS Questionnaire Form",
    "BasicGroupName": "Group: CNDS",
    "DescriptionFieldLabel": "About:",
    "DescriptionFieldValue": "CNDS Questionnaire Form For End Users",
    "QuestionnaireSubmitSuccess": "Спасибо за участие в этом опросе",
    "QuestionnaireDraftSuccess": "Changes saved successfully",
    "Loading": "Открытие приложения. Подождите..."
  };
});
