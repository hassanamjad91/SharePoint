define([], function() {
  return {
    "PropertyPaneDescription": "CNDS Questionnaire Manage Webpart",
    "BasicGroupName": "Group: CNDS",
    "DescriptionFieldLabel": "About:",
    "DescriptionFieldValue": "CNDS Questionnaire Management Webpart For Admins"
  };
});
