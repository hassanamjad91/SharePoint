define([], function () {
  return {
    "PropertyPaneDescription": "CNDS Questionnaire Form",
    "BasicGroupName": "Group: CNDS",
    "DescriptionFieldLabel": "About:",
    "DescriptionFieldValue": "CNDS Questionnaire Form For End Users",
    "QuestionnaireSubmitSuccess": "このアンケートにご協力いただきありがとうございます",
    "QuestionnaireDraftSuccess": "Changes saved successfully",
    "Loading": "アプリケーションを読み込んでいます。 お待ちください..."
  };
});
