define([], function () {
  return {
    "PropertyPaneDescription": "CNDS Questionnaire Form",
    "BasicGroupName": "Group: CNDS",
    "DescriptionFieldLabel": "About:",
    "DescriptionFieldValue": "CNDS Questionnaire Form For End Users",
    "QuestionnaireSubmitSuccess": "Grazie per aver partecipato a questo sondaggio",
    "QuestionnaireDraftSuccess": "Changes saved successfully",
    "Loading": "Caricamento applicazione..."
  };
});
