define([], function() {
  return {
    "PropertyPaneDescription": "CNDS Questionnaire Form",
    "BasicGroupName": "Group: CNDS",
    "DescriptionFieldLabel": "About:",
    "DescriptionFieldValue": "CNDS Questionnaire Form For End Users",
    "QuestionnaireSubmitSuccess": "Thank you for taking this survey",
    "QuestionnaireDraftSuccess": "Changes saved successfully",
    "Loading": "Loading Application. Please Wait..."
  };
});
