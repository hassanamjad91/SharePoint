define([], function() {
  return {
    "PropertyPaneDescription": "CNDS Questionnaire Notifier Webpart",
    "BasicGroupName": "Group: CNDS",
    "DescriptionFieldLabel": "About:",
    "DescriptionFieldValue": "CNDS Questionnaire Notifier Form For Admins"
  };
});
