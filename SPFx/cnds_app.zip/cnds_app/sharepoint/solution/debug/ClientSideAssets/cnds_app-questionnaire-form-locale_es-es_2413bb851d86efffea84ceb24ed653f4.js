define([], function () {
  return {
    "PropertyPaneDescription": "CNDS Questionnaire Form",
    "BasicGroupName": "Group: CNDS",
    "DescriptionFieldLabel": "About:",
    "DescriptionFieldValue": "CNDS Questionnaire Form For End Users",
    "QuestionnaireSubmitSuccess": "Gracias por responder esta encuesta",
    "QuestionnaireDraftSuccess": "Changes saved successfully",
    "Loading": "Cargando aplicación. Por favor, espere..."
  };
});
