define([], function () {
  return {
    "PropertyPaneDescription": "CNDS Questionnaire Form",
    "BasicGroupName": "Group: CNDS",
    "DescriptionFieldLabel": "About:",
    "DescriptionFieldValue": "CNDS Questionnaire Form For End Users",
    "QuestionnaireSubmitSuccess": "Vielen Dank, dass Sie an dieser Umfrage teilgenommen haben",
    "QuestionnaireDraftSuccess": "Changes saved successfully",
    "Loading": "Anwendung laden. Warten Sie mal..."
  };
});
