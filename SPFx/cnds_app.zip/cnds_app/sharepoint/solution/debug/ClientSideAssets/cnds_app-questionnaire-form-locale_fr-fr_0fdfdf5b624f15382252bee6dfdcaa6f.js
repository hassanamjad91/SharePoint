define([], function () {
  return {
    "PropertyPaneDescription": "CNDS Questionnaire Form",
    "BasicGroupName": "Group: CNDS",
    "DescriptionFieldLabel": "About:",
    "DescriptionFieldValue": "CNDS Questionnaire Form For End Users",
    "QuestionnaireSubmitSuccess": "Merci d'avoir répondu à cette enquête",
    "QuestionnaireDraftSuccess": "Changes saved successfully",
    "Loading": "Chargement de l'application. Veuillez patienter..."
  };
});
