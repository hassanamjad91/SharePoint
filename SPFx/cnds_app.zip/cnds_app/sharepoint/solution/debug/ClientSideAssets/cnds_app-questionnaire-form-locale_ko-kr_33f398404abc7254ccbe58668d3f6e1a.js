define([], function () {
  return {
    "PropertyPaneDescription": "CNDS Questionnaire Form",
    "BasicGroupName": "Group: CNDS",
    "DescriptionFieldLabel": "About:",
    "DescriptionFieldValue": "CNDS Questionnaire Form For End Users",
    "QuestionnaireSubmitSuccess": "설문 조사에 응 해주셔서 감사합니다",
    "QuestionnaireDraftSuccess": "Changes saved successfully",
    "Loading": "응용 프로그램을로드 중입니다. 기다려주세요..."    
  };
});
