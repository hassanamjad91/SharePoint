## How to configure development environment
# Install node.js version 10.19.0
# Install the following packages globally:
# - @microsoft/generator-sharepoint@1.10.0
# - gulp@3.9.1
# - ts-node@9.1.1
# - typescript@4.1.2
# Install the self trust certificate by running the following command in cmd:
# - 'gulp trust-dev-cert'

## How to test solution
# 1. Open solution folder in cmd
# 2. Execute command 'npm run proxy'
# 3. Follow on screen instructions to configure sp-rest-proxy
# 4. Open the proxy server in a browser window
# 5. To test the proxy server enter '/_api/web' in the 'SharePoint REST relative endpoint' text box and click 'Send HTTP GET'
# 6. After verifying that proxy server is working, close the cmd window
# 7. Open solution folder in cmd again and execute command 'npm run start'
# Note: You must redo steps 1 - 7 everytime the password is updated of account that was configured with sp-rest-proxy

## How to build solution
# 1. Open solution folder in cmd window
# 2. Execute command 'npm run build'

## How to package and deploy solution
# 1. Open solution folder in cmd window
# 2. Execute command 'npm run ship'
# Please ignore message "The build failed because a task wrote output to stderr." that will get displayed during build process
# 3. The packaged solution can be found inside './sharepoint' folder
# 4. Naviate to app catalog site of your Microsoft 365 tenant
# 5. Upload the packaged solution to AppCatalog library
# 6. Click 'Deploy' when prompted
# 7. Check In the solution file
# 7. Navigate to site contents page of site collection where you wish to install the app
# 8. Click 'New' > 'App' > 'Compliance Notice Distribution System'
