/* tslint:disable */
require("./style.module.css");
const styles = {
  app: 'app_f867e72a',
  container: 'container_f867e72a',
  grid: 'grid_f867e72a',
  row: 'row_f867e72a',
  column: 'column_f867e72a',
  'ms-Grid': 'ms-Grid_f867e72a',
  col_1: 'col_1_f867e72a',
  col_2: 'col_2_f867e72a',
  col_3: 'col_3_f867e72a',
  col_4: 'col_4_f867e72a',
  col_8: 'col_8_f867e72a',
  col_10: 'col_10_f867e72a',
  col_12: 'col_12_f867e72a',
  title: 'title_f867e72a',
  subTitle: 'subTitle_f867e72a',
  description: 'description_f867e72a',
  button: 'button_f867e72a',
  label: 'label_f867e72a',
  disabled: 'disabled_f867e72a',
  invalid: 'invalid_f867e72a',
  error: 'error_f867e72a',
  warning: 'warning_f867e72a',
  success: 'success_f867e72a'
};

export default styles;
/* tslint:enable */