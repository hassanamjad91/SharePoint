export enum LogType {
  Error = "Error",
  Trace = "Trace",
}

export default {};
