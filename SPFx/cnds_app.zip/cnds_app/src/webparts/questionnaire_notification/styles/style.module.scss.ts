/* tslint:disable */
require("./style.module.css");
const styles = {
  app: 'app_8ed6f5ac',
  container: 'container_8ed6f5ac',
  grid: 'grid_8ed6f5ac',
  row: 'row_8ed6f5ac',
  column: 'column_8ed6f5ac',
  'ms-Grid': 'ms-Grid_8ed6f5ac',
  col_1: 'col_1_8ed6f5ac',
  col_2: 'col_2_8ed6f5ac',
  col_3: 'col_3_8ed6f5ac',
  col_4: 'col_4_8ed6f5ac',
  col_6: 'col_6_8ed6f5ac',
  col_8: 'col_8_8ed6f5ac',
  col_10: 'col_10_8ed6f5ac',
  col_12: 'col_12_8ed6f5ac',
  title: 'title_8ed6f5ac',
  subTitle: 'subTitle_8ed6f5ac',
  description: 'description_8ed6f5ac',
  button: 'button_8ed6f5ac',
  label: 'label_8ed6f5ac',
  people_picker: 'people_picker_8ed6f5ac',
  disabled: 'disabled_8ed6f5ac',
  ckeditor4: 'ckeditor4_8ed6f5ac',
  file: 'file_8ed6f5ac',
  file_uploaded: 'file_uploaded_8ed6f5ac',
  file_uploaded_remove: 'file_uploaded_remove_8ed6f5ac',
  file_native: 'file_native_8ed6f5ac',
  file_native_remove: 'file_native_remove_8ed6f5ac',
  invalid: 'invalid_8ed6f5ac',
  error: 'error_8ed6f5ac',
  warning: 'warning_8ed6f5ac',
  success: 'success_8ed6f5ac'
};

export default styles;
/* tslint:enable */