import * as Yup from 'yup';

const validation = Yup.object().shape({

});
export default validation;
