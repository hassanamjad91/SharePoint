/* tslint:disable */
require("./style.module.css");
const styles = {
  app: 'app_25d7c9d1',
  container: 'container_25d7c9d1',
  grid: 'grid_25d7c9d1',
  row: 'row_25d7c9d1',
  column: 'column_25d7c9d1',
  'ms-Grid': 'ms-Grid_25d7c9d1',
  col_1: 'col_1_25d7c9d1',
  col_2: 'col_2_25d7c9d1',
  col_3: 'col_3_25d7c9d1',
  col_4: 'col_4_25d7c9d1',
  col_6: 'col_6_25d7c9d1',
  col_8: 'col_8_25d7c9d1',
  col_10: 'col_10_25d7c9d1',
  col_12: 'col_12_25d7c9d1',
  title: 'title_25d7c9d1',
  subTitle: 'subTitle_25d7c9d1',
  description: 'description_25d7c9d1',
  button: 'button_25d7c9d1',
  label: 'label_25d7c9d1',
  command_button: 'command_button_25d7c9d1',
  command_bar: 'command_bar_25d7c9d1',
  people_picker: 'people_picker_25d7c9d1',
  disabled: 'disabled_25d7c9d1',
  invalid: 'invalid_25d7c9d1',
  error: 'error_25d7c9d1',
  warning: 'warning_25d7c9d1',
  success: 'success_25d7c9d1'
};

export default styles;
/* tslint:enable */