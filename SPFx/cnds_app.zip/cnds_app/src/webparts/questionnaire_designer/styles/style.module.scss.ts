/* tslint:disable */
require("./style.module.css");
const styles = {
  app: 'app_d602ec2d',
  container: 'container_d602ec2d',
  grid: 'grid_d602ec2d',
  row: 'row_d602ec2d',
  column: 'column_d602ec2d',
  'ms-Grid': 'ms-Grid_d602ec2d',
  col_1: 'col_1_d602ec2d',
  col_2: 'col_2_d602ec2d',
  col_3: 'col_3_d602ec2d',
  col_4: 'col_4_d602ec2d',
  col_6: 'col_6_d602ec2d',
  col_8: 'col_8_d602ec2d',
  col_10: 'col_10_d602ec2d',
  col_12: 'col_12_d602ec2d',
  title: 'title_d602ec2d',
  subTitle: 'subTitle_d602ec2d',
  description: 'description_d602ec2d',
  button: 'button_d602ec2d',
  label: 'label_d602ec2d',
  drop_zone: 'drop_zone_d602ec2d',
  button_option: 'button_option_d602ec2d',
  command_button: 'command_button_d602ec2d',
  command_bar: 'command_bar_d602ec2d',
  ckeditor4: 'ckeditor4_d602ec2d',
  disabled: 'disabled_d602ec2d',
  pill: 'pill_d602ec2d',
  pill_content: 'pill_content_d602ec2d',
  pill_remove: 'pill_remove_d602ec2d',
  invalid: 'invalid_d602ec2d',
  error: 'error_d602ec2d',
  info: 'info_d602ec2d',
  warning: 'warning_d602ec2d',
  success: 'success_d602ec2d'
};

export default styles;
/* tslint:enable */